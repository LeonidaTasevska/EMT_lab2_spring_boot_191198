package lab2.lab2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
