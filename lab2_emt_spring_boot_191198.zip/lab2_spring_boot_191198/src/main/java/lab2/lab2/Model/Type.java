package lab2.lab2.Model;

import org.springframework.security.core.GrantedAuthority;

public enum Type  {

    NOVEL,
    THRILER,
    HISTORY,
    FANTASY,
    BIOGRAPHY,
    CLASSICS,
    DRAMA



}
